document.querySelector('HEADER').style.color = '#FF0000';
